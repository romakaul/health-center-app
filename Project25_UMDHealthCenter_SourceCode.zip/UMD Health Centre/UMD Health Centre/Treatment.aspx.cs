﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace UMD_Health_Centre
{
    public partial class Treatment : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["UMDHealthCentre_ConnectionString"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            con.Open();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("insert into [UmdHealthCentre.Treatment] values('"+txttreatmentID.Text+"','"+txtamount.Text+"')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            Label1.Visible = true;
            Label1.Text = "Data stored successfully";
            txttreatmentID.Text = "";
            txtamount.Text = "";
            
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
       
                GvTreatment.DataBind();
           
        
        GvTreatment.Visible = true;

        }
        

        protected void btnhome_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/HomePage", true);

        }

        protected void btSearch_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/Search", true);
        }
    }
}