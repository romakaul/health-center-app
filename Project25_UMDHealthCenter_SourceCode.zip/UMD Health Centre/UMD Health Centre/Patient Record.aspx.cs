﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace UMD_Health_Centre
{
    public partial class Patient_Record : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["UMDHealthCentre_ConnectionString"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            con.Open();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("insert into [UmdHealthCentre.PatientRecord] values('"+txtrecordID.Text+"','"+txtpatientName.Text+ "','"+txtinsuranceID1.Text+"')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            Label1.Visible = true;
            Label1.Text = "Data stored successfully";
            txtrecordID.Text = "";
            txtpatientName.Text = "";
            txtinsuranceID1.Text = "";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            GridView2.DataBind();


            GridView2.Visible = true;

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/HomePage", true);
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/Search", true);
        }
    }
}