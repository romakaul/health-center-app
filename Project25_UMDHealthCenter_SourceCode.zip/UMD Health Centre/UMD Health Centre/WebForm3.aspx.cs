﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace UMD_Health_Centre
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["UMDHealthCentre_ConnectionString"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            con.Open();
        }

        

        protected void Button3_Click1(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("select * from PatientBill where recordID = " + txtRecordID.Text, con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            GridView2.Visible = true;
            GridView2.DataSource = dr;
            GridView2.DataBind();

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/HomePage", true);
        }
    }
}