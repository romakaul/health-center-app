﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UMD_Health_Centre
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnDoctor_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/Doctor", true);
        }

        protected void btnPatient_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/Patient%20Record", true);
        }

        protected void btnInsurance_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/Insurance.aspx", true);
        }

        protected void btnMedicine_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/Medicine", true);
        }

        protected void btnTreatment_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/Treatment", true);
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/Search", true);
        }

        protected void btnSearch0_Click(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/WebForm3", true);
        }
    }
}