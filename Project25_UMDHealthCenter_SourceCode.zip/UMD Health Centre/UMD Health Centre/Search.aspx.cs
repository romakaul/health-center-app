﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace UMD_Health_Centre
{
    public partial class Search : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["UMDHealthCentre_ConnectionString"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            con.Open();
        }

      

        protected void btnHome_Click1(object sender, EventArgs e)
        {
            Response.Redirect("http://localhost:58874/HomePage", true);
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SqlCommand cmd;
            SqlDataReader dr;
            if (DropDownList1.SelectedIndex == 0)
            { lblmsg.Visible = true; }


            if (DropDownList1.SelectedIndex == 1)
            {
                cmd = new SqlCommand("Select  m.medName, Count( r.recordID) as 'Number of Patients' , m.manufacturer From[UmdHealthCentre.Medicine] m, [UmdHealthCentre.Prescribed] r Where m.medID = r.medID group by m.medName, m.manufacturer order by m.medName desc", con);
                dr = cmd.ExecuteReader();
                // GvTreatment.DataSource = dr;
                if (dr.HasRows)
                {
                    //  GvTreatment.DataSource = dr;
                    //GvTreatment.DataBind();
                    lblmsg.Visible = false;
                    GridView1.DataSource = dr;
                    GridView1.DataBind();
                    GridView1.Visible = true;
                }
                else
                {
                    GridView1.Visible = false;
                    lblmsg.Visible = true;
                    // GvTreatment.DataSource = null;
                    //vTreatment.DataBind();
                }

            }
            if (DropDownList1.SelectedIndex == 2)
            {
                cmd = new SqlCommand("select f.recordID, p.PatientName, t.amount, t.treatmentID from[UmdHealthCentre.Treatment] t, [UmdHealthCentre.Treats] f, [UmdHealthCentre.PatientRecord] p where t.treatmentID = f.treatmentID and f.recordID = p.recordID;", con);
                dr = cmd.ExecuteReader();
                // GvTreatment.DataSource = dr;
                if (dr.HasRows)
                {
                    //  GvTreatment.DataSource = dr;
                    //GvTreatment.DataBind();
                    lblmsg.Visible = false;
                    GridView1.DataSource = dr;
                    GridView1.DataBind();
                    GridView1.Visible = true;
                }
                else
                {
                    GridView1.Visible = false;
                    lblmsg.Visible = true;
                    // GvTreatment.DataSource = null;
                    //vTreatment.DataBind();
                }

            }
            if (DropDownList1.SelectedIndex == 3)
            {
                cmd = new SqlCommand("Select p.recordID, p.patientName From [UmdHealthCentre.PatientRecord] p, [UmdHealthCentre.Treats] t Where t.treatmentID = (select treatmentID From [UmdHealthCentre.Treatment] Where amount= (select MAX(amount) From [UmdHealthCentre.Treatment])) AND p.recordID = t.recordID", con);
                dr = cmd.ExecuteReader();
                // GvTreatment.DataSource = dr;
                if (dr.HasRows)
                {
                    //  GvTreatment.DataSource = dr;
                    //GvTreatment.DataBind();
                    lblmsg.Visible = false;
                    GridView1.DataSource = dr;
                    GridView1.DataBind();
                    GridView1.Visible = true;
                }
                else
                {
                    GridView1.Visible = false;
                    lblmsg.Visible = true;
                    // GvTreatment.DataSource = null;
                    //vTreatment.DataBind();
                }

            }
            if (DropDownList1.SelectedIndex == 4)
            {
                cmd = new SqlCommand("Select distinct d.docID, d.docName, p.patientName, p.recordID, t.treatmentID From[UmdHealthCentre.PatientRecord] p, [UmdHealthCentre.Treats] t, [UmdHealthCentre.Treatment] r, [UmdHealthCentre.Doctor] d Where t.treatmentID IN (select treatmentID From[UmdHealthCentre.Treatment] Where amount > 500) and p.recordID = t.recordID and  t.docID= d.docId", con);
                dr = cmd.ExecuteReader();
                // GvTreatment.DataSource = dr;
                if (dr.HasRows)
                {
                    //  GvTreatment.DataSource = dr;
                    //GvTreatment.DataBind();
                    lblmsg.Visible = false;
                    GridView1.DataSource = dr;
                    GridView1.DataBind();
                    GridView1.Visible = true;
                }
                else
                {
                    GridView1.Visible = false;
                    lblmsg.Visible = true;
                    // GvTreatment.DataSource = null;
                    //vTreatment.DataBind();
                }

            }

            if (DropDownList1.SelectedIndex == 5)
            {
                cmd = new SqlCommand("Select d.docID, d.docName From [UmdHealthCentre.Treats] t, [UmdHealthCentre.Doctor] d Where t.docID= d.DocID Group by d.docID, d.docName Having Count(*) > 5", con);
                dr = cmd.ExecuteReader();
                // GvTreatment.DataSource = dr;
                if (dr.HasRows)
                {
                    //  GvTreatment.DataSource = dr;
                    //GvTreatment.DataBind();
                    lblmsg.Visible = false;
                    GridView1.DataSource = dr;
                    GridView1.DataBind();
                    GridView1.Visible = true;
                }
                else
                {
                    GridView1.Visible = false;
                    lblmsg.Visible = true;
                    // GvTreatment.DataSource = null;
                    //vTreatment.DataBind();
                }

            }

        }
    }

    }
